# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
import os

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.tvigle import Tvigle
import simplemedia
from simplemedia import py2_decode

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

cache_dir = os.path.join(plugin.profile_dir, 'cache')
api = Tvigle(6, 'b5474cc8d4cf06bad05a7e4a6915e519', 'f84547e3ee153b79fcbd0cabad542087', cache_dir)

@plugin.route('/')
def root():
    if plugin.params.action is not None:
        if plugin.params.action == 'search':
            search()
    else:
        plugin.create_directory(_list_root())

def _list_root():

    channels = _read_channels()

    for channel in channels:
        url = plugin.url_for('channel', channel=channel['id'])
        list_item = {'label': channel['title'],
                     'url': url,
                     'icon': channel['icon'],
                     'fanart': channel['fanart'],
                     'info': {'video': {'plot': plugin.remove_html(channel['slogon']),
                                        },
                              },
                     'content_lookup': False,
                     }
        yield list_item

    url = plugin.url_for('search_history')
    list_item = {'label': _('Search'),
                 'url': url,
                 'icon': plugin.get_image('DefaultAddonsSearch.png'),
                 'fanart': plugin.fanart,
                 'content_lookup': False,
                 }
    yield list_item

@plugin.cached(180)
def _read_channels():
    result = []
    for channel in api.channels():
        result.append(channel)

    return result

@plugin.route('/channel/<channel_id>')
def channel(channel_id):

    catalog_info = api.channel_catalog(channel_id)

    params = {'items': _list_catalog(catalog_info),
              'total_items': catalog_info['count'],
              'content': 'movies',
              'sort_methods': xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS,
              }
    plugin.create_directory(**params)

def _list_catalog(data):
    for item in data['list']:
        listitem = _get_listitem(item, item['type'])
        yield listitem

@plugin.route('/channel/<channel_id>/catalog/<catalog_uid>')
def catalog(channel_id, catalog_uid):

    catalog_info = api.catalog_childrens(channel_id, catalog_uid)

    params = {'items': _list_seasons(catalog_info),
              'total_items': catalog_info['count'],
              'content': 'seasons',
              'sort_methods': xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS,
              }
    plugin.create_directory(**params)

def _list_seasons(data):
    for item in data['list']:
        listitem = _get_listitem(item, 'season')
        yield listitem

@plugin.route('/channel/<channel_id>/catalog/<catalog_uid>/videos')
def videos(channel_id, catalog_uid):

    videos_info = api.catalog_videos(channel_id, catalog_uid)
    params = {'items': _list_videos(videos_info),
              'total_items': videos_info['count'],
              'content': 'episodes',
              'sort_methods': xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS,
              }
    plugin.create_directory(**params)

def _list_videos(data):
    sort_methods = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS

    for item in data['list']:
        listitem = _get_listitem(item, 'episode')
        yield listitem

def _get_listitem(item, mediatype):
    properties = {}
    if mediatype == 'movie':
        url = plugin.url_for('play_video', video_id=item['id'])
        is_folder = False
        is_playable = True
    elif mediatype == 'episode':
        url = plugin.url_for('play_video', video_id=item['id'])
        is_folder = False
        is_playable = True
    elif mediatype in ['tvshow', 'season']:
        is_folder = True
        is_playable = False
        if item['has_children']:
            url = plugin.url_for('catalog', channel_id = item['channel_id'], catalog_uid=item['uid'])
        else:
            url = plugin.url_for('videos', item['channel_id'], catalog_uid=item['uid'])

        properties = {'TotalSeasons': str(max(item['cntCat'], 1)),
                      'TotalEpisodes': str(item['cnt']),
                      'WatchedEpisodes': '0',
                      }

    mpaa = api.get_age_restricted_rating(item.get('age_restrictions'), 'mpaa')

    listitem = {'label': item['name'],
                'info': {'video': {'title': item['name'],
                                   'originaltitle': item['name'],
                                   'sorttitle': item['name'],
                                   'plot': plugin.remove_html(item['description']),
                                   'mpaa': mpaa,
                                   'duration': item.get('duration_in_ms', 0)/1000,
                                   'dateadded': item.get('publication_start_date', ''),
                                   'mediatype': mediatype,
                                   },
                         },
                'fanart':  plugin.fanart,
                'thumb':  item['thumbnail'],
                'content_lookup': False,
                'is_folder': is_folder,
                'is_playable': is_playable,
                'url': url,
                'properties': properties,
                }

    return listitem

@plugin.route('/video/<video_id>')
def play_video(video_id):
    episode = api.video(video_id)

    list_item = _get_listitem(episode, 'episode')
    succeeded = False

    dialog = xbmcgui.Dialog()
    if not episode['isGeoAccess']:
        dialog.ok(plugin.name, _('This video not available in your region'))
    else:
        list_item['path'] = _get_video_path(episode['links'])
        succeeded = True

    plugin.resolve_url(list_item, succeeded)

def _get_video_path(links):

    video_quality = plugin.get_setting('video_quality')

    path = ''
    if video_quality == 0:
        if links.get('hls') is not None:
            path = 'http:{0}'.format(links['hls'])
        else:
            video_quality = 10

    if not path:
        mp4 = links['mp4']
        if (not path or video_quality >= 1) and mp4.get('240p') is not None:
            path = mp4['240p']
        if (not path or video_quality >= 1) and mp4.get('360p') is not None:
            path = mp4['360p']
        if (not path or video_quality >= 2) and mp4.get('480p') is not None:
            path = mp4['480p']
        if (not path or video_quality >= 3) and mp4.get('720p') is not None:
            path = mp4['720p']
        if (not path or video_quality >= 4) and mp4.get('1080p') is not None:
            path = mp4['1080p']

    return path

@plugin.route('/search/history')
def search_history():

    with plugin.get_storage('__history__.pcl') as storage:
        history = storage.get('history', [])

        if len(history) > plugin.get_setting('history_length'):
            history[plugin.history_length - len(history):] = []
            storage['history'] = history

    listing = []
    listing.append({'label': _('New Search...'),
                    'url': plugin.url_for('search'),
                    'icon': plugin.get_image('DefaultAddonsSearch.png'),
                    'fanart': plugin.fanart})

    for item in history:
        listing.append({'label': item['keyword'],
                        'url': plugin.url_for('search', keyword=item['keyword']),
                        'icon': plugin.icon,
                        'fanart': plugin.fanart})

    plugin.create_directory(listing, content='files', category=_('Search'))

@plugin.route('/search')
def search():

    keyword  = plugin.params.keyword or ''
    usearch  = (plugin.params.usearch == 'True')

    new_search = (keyword == '')

    if not keyword:
        kbd = xbmc.Keyboard('', _('Search'))
        kbd.doModal()
        if kbd.isConfirmed():
            keyword = kbd.getText()

    if keyword and new_search and not usearch:
        with plugin.get_storage('__history__.pcl') as storage:
            history = storage.get('history', [])
            history.insert(0, {'keyword': keyword})
            if len(history) > plugin.get_setting('history_length'):
                history.pop(-1)
            storage['history'] = history

        url = plugin.url_for('search', keyword=py2_decode(keyword))
        xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword:
        videos_info = api.search(keyword)
        plugin.create_directory(_list_videos(videos_info), content='videos', category=_('Search'))

if __name__ == '__main__':
    plugin.run()