# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import requests
import os
import sqlite3
import time
import hashlib

import json

from future.utils import PY3, iteritems

class DataBase(object):

    def __init__( self, cache_dir, cache_hours=0 ):
        self._version = 1

        self._time_delta = cache_hours * 3600 #time in seconds

        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        db_path = os.path.join(cache_dir, 'cache.db')

        db_exist = os.path.exists(db_path)

        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = self._dict_factory

        if db_exist:
            self.check_for_update()
        else:
            self.create_database()

    @staticmethod
    def _dict_factory(cursor, row):
        d = {}
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d

    def check_for_update(self):

#        c = self.conn.cursor()
#        c.execute('SELECT idVersion FROM version LIMIT 1')
#
#        result = c.fetchone()
#        db_version = result['idVersion']
#
#        upd_version = 2
#        if db_version < upd_version:
#            c.execute('DELETE FROM version')
#            c.execute('INSERT INTO version (idVersion) VALUES (:version)', {'version': upd_version} )
#            db_version = upd_version
#
#            self.conn.commit()
        pass

    def create_database(self):

        c = self.conn.cursor()
        c.execute('CREATE TABLE version (idVersion integer)')
        c.execute('INSERT INTO version (idVersion) VALUES (:version)', {'version': self._version} )

        c.execute('CREATE TABLE catalogs (id integer, channel_id integer, parent_id integer, uid integer, tp integer, data text)')
        c.execute('CREATE UNIQUE INDEX catalogs_idx ON catalogs(id, channel_id, parent_id, uid, tp)')

        c.execute('CREATE TABLE channels (id integer, time integer)')
        c.execute('CREATE UNIQUE INDEX channels_idx ON catalogs(id)')

        c.execute('CREATE TABLE videos (id integer, channel_id integer, category_id integer, src_id integer, data text)')
        c.execute('CREATE UNIQUE INDEX videos_idx ON videos(id, channel_id, category_id, src_id)')

        self.conn.commit()

    def channel_cached(self, channel_id):
        sql_params = {'id': int(channel_id),
                      }

        c = self.conn.cursor()
        c.execute('SELECT time FROM channels WHERE id = :id LIMIT 1', sql_params)

        channel = c.fetchone()
        if channel is not None:
            result = channel['time'] < time.time() - self._time_delta
            if not result:
                self._remove_channel(channel_id)
        else:
            result = False
        return result

    def set_channel_time(self, channel_id):

        sql_params = {'channel_id': int(channel_id),
                      'time': time.time()}

        c = self.conn.cursor()
        c.execute('INSERT OR REPLACE INTO channels (id, time) VALUES (:channel_id, :time)', sql_params)

        self.conn.commit()

    def set_catalogs(self, catalogs):

        c = self.conn.cursor()

        items = []
        for catalog in catalogs:
            item = {'id': int(catalog['id']),
                    'channel_id': int(catalog['channel_id']),
                    'parent_id': int(catalog['parent_id']),
                    'uid': int(catalog['uid']) if catalog['uid'] is not None else None,
                    'tp': int(catalog['tp']),
                    'data': json.dumps(catalog),
                    }
            items.append(item)
        c.executemany('INSERT OR REPLACE INTO catalogs (id, channel_id, parent_id, uid, tp, data) VALUES (:id, :channel_id, :parent_id, :uid, :tp, :data)', items)

        self.conn.commit()

    def set_videos(self, videos):

        c = self.conn.cursor()

        items = []
        for video in videos:
            item = {'id': int(video['id']),
                    'channel_id': int(video['channel_id']),
                    'category_id': int(video['category_id']),
                    'src_id': int(video['src_id']),
                    'data': json.dumps(video),
                    }
            items.append(item)
        c.executemany('INSERT OR REPLACE INTO videos (id, channel_id, category_id, src_id, data) VALUES (:id, :channel_id, :category_id, :src_id, :data)', items)

        self.conn.commit()

    def get_childrens(self, channel_id, parent_id=0):
#        sql_params = {'channel_id': int(channel_id),
#                      'parent_id': int(parent_id),
#                      }

        c = self.conn.cursor()
#        c.execute('SELECT data FROM catalogs WHERE channel_id = :channel_id AND parent_id = :parent_id ORDER BY id', sql_params)
        c.execute('SELECT data FROM catalogs WHERE channel_id = {0} AND parent_id = {1} ORDER BY id'.format(channel_id, parent_id))

        while True:
            row = c.fetchone()
            if row is not None:
                yield json.loads(row['data'])
            else:
                break

    def get_videos(self, channel_id, category_id=0):

        c = self.conn.cursor()

        if category_id == 0:
            sql_params = {'channel_id': int(channel_id),
                          }
            c.execute('SELECT data FROM videos WHERE channel_id = :channel_id ORDER BY id', sql_params)

        else:
            sql_params = {'channel_id': int(channel_id),
                          'category_id': int(category_id),
                          }

            c.execute('SELECT data FROM videos WHERE channel_id = :channel_id and category_id = :category_id ORDER BY id', sql_params)

        while True:
            row = c.fetchone()
            if row is not None:
                yield json.loads(row['data'])
            else:
                break

    def get_catalog(self, channel_id, catalog_uid):
        sql_params = {'channel_id': int(channel_id),
                      'catalog_uid': int(catalog_uid),
                      }

        c = self.conn.cursor()
        c.execute('SELECT data FROM catalogs WHERE channel_id = :channel_id and uid = :catalog_uid LIMIT 1', sql_params)

        row = c.fetchone()
        return json.loads(row['data'])

    def _remove_channel(self, channel_id):
        sql_params = {'channel_id': int(channel_id),
                      }

        c = self.conn.cursor()
        c.execute('DELETE FROM channels WHERE id = :channel_id', sql_params)
        c.execute('DELETE FROM catalogs WHERE channel_id = :channel_id', sql_params)
        c.execute('DELETE FROM videos WHERE channel_id = :channel_id', sql_params)

        self.conn.commit()

class Tvigle(object):

    _api_url = 'http://rest.pub.tvigle.ru/agr/'

    class APIException(Exception):
        pass

    def __init__(self, app, key, secret, cache_dir):

        # Values for request encoding
        self._app = app
        self._key = key
        self._secret = secret
        self._db = DataBase(cache_dir)

    def _get_access_token(self, url):

        sig_url = url
        if sig_url[-1] != '/':
            sig_url += '/'

        sig_url += self._secret
        sig_url = sig_url.replace('/', '#')
        md5 = hashlib.md5()
        md5.update(sig_url.encode('utf-8'))

        return md5.hexdigest()

    def _http_request(self, url_path='', params=None):
        params = params or {}

        url = '{0}/app/{1}/{2}/'.format(self._key, self._app, url_path)

        params['access_token'] = self._get_access_token(url)

        url = self._api_url + url
        try:
            r = requests.get(url, params)
            r.raise_for_status()
        except requests.ConnectionError:
            raise self.APIException('Connection error')

        return r

    def _extract_json(self, r):
        try:
            j = r.json()
        except ValueError as err:
            raise ApiError(err)

        if isinstance(j, dict) \
          and j.get('error') is not None:
            raise self.ApiError(j['error']['message'].encode('utf-8'))
        return j

    def channels(self):
        url = 'channels'

        r = self._http_request(url)
        j = self._extract_json(r)

        for channel in j:
            if channel['category_id'] is not None:
                yield {'id': channel['id'],
                       'title': channel['name'],
                       'description': channel['description'],
                       'slogon': channel['slogon'],
                       'category_id': channel['category_id'],
                       'fanart': channel['bg'],
                       'icon': channel['icon'],
                       }

    def channel_catalog(self, channel_id):

        self._check_cache(channel_id)

        catalogs = []
        added_uids = []
        for catalog in self._db.get_childrens(channel_id):
            for category in self._db.get_childrens(channel_id, catalog['id']):
                for item in self._db.get_childrens(channel_id, category['id']):
                    if not item['uid'] in added_uids:
                        catalogs.append(item)
                        added_uids.append(item['uid'])
        videos = []
        added_uids = []
        for video in self._db.get_videos(channel_id):
            if not video['src_id'] in added_uids:
                videos.append(video)
                added_uids.append(video['src_id'])

        result = {'count': len(catalogs) + len(videos),
                  'list': self._catalog_list(catalogs, videos),
                  }
        return result

    @classmethod
    def _catalog_list(cls, catalogs, videos):
        for catalog in catalogs:
            yield cls._make_item(catalog, 'tvshow')
        for video in videos:
            yield cls._make_item(video, 'movie')

    def _check_cache(self, channel_id):
        if not self._db.channel_cached(channel_id):
            url = 'channels/{0}/catalog'.format(channel_id)
            r = self._http_request(url)
            catalogs = self._extract_json(r)
            self._db.set_catalogs(catalogs)

            for catalog in self._db.get_childrens(channel_id):
                for category in self._db.get_childrens(channel_id, catalog['id']):
                    url = 'channels/{0}/catalog/{1}/video'.format(channel_id, category['id'])
                    r = self._http_request(url)
                    videos = self._extract_json(r)
                    self._db.set_videos(videos)

            self._db.set_channel_time(channel_id)

    def catalog_childrens(self, channel_id, catalog_uid):

        self._check_cache(channel_id)
        catalog = self._db.get_catalog(channel_id, catalog_uid)

        catalogs = []
        added_uids = []

        for item in self._db.get_childrens(catalog['channel_id'], catalog['id']):
            if not item['uid'] in added_uids:
                catalogs.append(item)
                added_uids.append(item['uid'])

        result = {'count': len(catalogs),
                  'list': self._catalog_items_list(catalogs),
                  }
        return result

    @classmethod
    def _catalog_items_list(cls, catalogs):
        for catalog in catalogs:
            yield cls._make_item(catalog, 'season')

    @staticmethod
    def _make_item(data, item_type):
        if item_type in ['tvshow', 'season']:
            item = {'id': data['id'],
                     'name': data['name'],
                     'description': data['description'],
                     'thumbnail': data['thumbnail'],
                     'tp': data['tp'],
                     'channel_id': data['channel_id'],
                     'parent_id': data['parent_id'],
                     'has_children': data['has_children'],
                     'adv_cat': data['adv_сat'],
                     'cnt': data['cnt'],
                     'cntCat': data['cntCat'],
                     'uid': data['uid'],
                     'age_restrictions': data['age_restrictions'],
                     'type': item_type,
                     }
        elif item_type in ['episode', 'movie']:
            item = {'id': data['id'],
                    'name': data['name'],
                    'description': data['description'],
                    'thumbnail': data['thumbnail'],
                    'age_restrictions': data['age_restrictions'],
                    'publication_start_date': data['publication_start_date'],
                    'duration_in_ms': data['duration_in_ms'],
                    'src_id': data['src_id'],
                    'channel_id': data['channel_id'],
                    'category_id': data['category_id'],
                     'type': item_type,
                     }

        return item

    def catalog_videos(self, channel_id, catalog_uid):

        self._check_cache(channel_id)
        catalog = self._db.get_catalog(channel_id, catalog_uid)
        url = 'channels/{0}/catalog/{1}/video'.format(channel_id, catalog['id'])

        r = self._http_request(url)
        j = self._extract_json(r)


        result = {'count': len(j),
                  'list': self._channel_catalog_videos_list(j),
                  }
        return result

    def search(self, keyword):

        url = 'video'

        u_params = {'q': keyword,
                    }

        r = self._http_request(url, params=u_params)
        j = self._extract_json(r)


        result = {'count': len(j),
                  'list': self._channel_catalog_videos_list(j),
                  }
        return result

    @classmethod
    def _channel_catalog_videos_list(cls, data):
        for item in data:
            yield cls._make_item(item, 'episode')

    def video(self, video_id):
        url = 'video/{0}'.format(video_id)

        r = self._http_request(url)
        j = self._extract_json(r)

        return {'id': j['id'],
                'name': j['name'],
                'description': j['description'],
                'thumbnail': j['thumbnail'],
                'age_restrictions': j['age_restrictions'],
                'publication_start_date': j['publication_start_date'],
                'duration_in_ms': j['duration_in_ms'],
                'channel_id': j['channel_id'],
                'category_id': j['category_id'],
                'src_id': j['src_id'],
                'links': j['links'] if j['isGeoAccess'] else {},
                'isGeoAccess': j['isGeoAccess'],
                }

    @staticmethod
    def get_age_restricted_rating(min_age, rating_type):
        rars = min_age
        if min_age == '0+':
            mpaa = 'G'
        elif min_age == '6+':
            mpaa = 'PG'
        elif min_age == '12+':
            mpaa = 'PG-13'
        elif min_age == '16+':
            mpaa = 'R'
        elif min_age == '18+':
            mpaa = 'NC-17'
        else:
            mpaa = ''

        result = {'rars': rars,
                  'mpaa': mpaa,
                  }

        return result.get(rating_type, '')
