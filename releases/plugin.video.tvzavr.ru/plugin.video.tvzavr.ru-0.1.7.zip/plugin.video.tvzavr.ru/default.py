﻿# -*- coding: utf-8 -*-
# Module: default
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import urllib
from urllib import urlencode
from urlparse import parse_qsl
import resources.lib.tvzavr_api as tvzavr_api
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon(id='plugin.video.tvzavr.ru')

addon_icon    = _addon.getAddonInfo('icon')
addon_fanart  = _addon.getAddonInfo('fanart')
addon_name    = _addon.getAddonInfo('name')

local_str = _addon.getLocalizedString

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def init_tvzavr():
    settings_list = ['email', 'password', 'userid', 'vlog-ssid', 'limit', 'sort', 'plus', 'adult', 'rate_sourse', 'debug', 'video_quality', 'audio_lang']

    settings = {}
    for id in settings_list:
        settings[id] = get_setting(id)

    settings['addon'] = _addon
    settings['addon_id'] = _addon.getAddonInfo('id')

    return tvzavr_api.tvzavr(settings)

def get_setting(id):
    value = _addon.getSetting(id)

    if id == 'limit':
        return int(value)
    elif id == 'sort':
        if   value == '0': return 'last-random'
        elif value == '1': return 'view'
        elif value == '2': return 'last'
        elif value == '3': return 'rate'
        elif value == '4': return 'name'
        elif value == '5': return 'rand'
        else: return 'last'
    elif id == 'plus':
        return '2' if value == 'true' else '0'
    elif id == 'adult':
        return '1' if value == 'true' else '0'
    elif id in ['userid', 'vlog-ssid']:
        return value if value != '' else 'null'
    elif id in ['debug', 'use_subtitles', 'use_atl_names']:
        return True if value == 'true' else False
    elif id == 'audio_lang':
        if value == '0': return 'rus'
        if value == '1': return 'orig'
        else: return 'rus'
    elif id == 'video_quality':
        if   value == '0': return 7680 #4320p (8K)
        elif value == '1': return 3840 #2160p (4K)
        elif value == '2': return 2560 #1440p (HD)
        elif value == '3': return 1920 #1080p (HD)
        elif value == '4': return 1280 #720p (HD)
        elif value == '5': return 960  #480p
        elif value == '6': return 640  #360p
        elif value == '7': return 480  #240p
        else: return 1280              #720p (HD)
    else:
        return value

def show_error(response):
    error_title = local_str(30057) + ' %d' % response['status']
    error_text = response['error'][0]['description_ru']
    if response['status'] == 12 or response['status'] == 68:
        xbmcgui.Dialog().ok(addon_name, error_title, error_text)
    else:
        xbmcgui.Dialog().notification(error_title, error_text)

def get_categories():
    userid = get_setting('userid')

    categories = []

    categories.append({'action': 'catalog', 'name': local_str(30041), 'params':{'_recommended': 'yes', '_client_ctx': 10}})
    categories.append({'action': 'catalog', 'name': local_str(30042), 'params':{'_cats': 71, '_client_ctx': 2}})
    categories.append({'action': 'catalog', 'name': local_str(30043), 'params':{'_cats': 675, '_client_ctx': 3}})
    categories.append({'action': 'catalog', 'name': local_str(30044), 'params':{'_cats': 678, '_client_ctx': 4}})
    if userid != 'null':
        categories.append({'action': 'favorites', 'name': local_str(30045)})
        categories.append({'action': 'paid', 'name': local_str(30046)})
    categories.append({'action': 'search', 'name': local_str(30047), 'params': {'history': 0}})

    return categories

def list_categories():
    xbmcplugin.setContent(_handle, 'files')
    categories = get_categories()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['name'])
        url = get_url(action=category['action'])
        params = category.get('params')
        list_item.setArt({'fanart':addon_fanart, 'poster': addon_icon})

        if params != None:
            url = url + '&' + urlencode(params)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.endOfDirectory(_handle)

def list_videos( video_list ):

    for video in video_list:

        label = video['label']
        if get_setting('use_atl_names'):
            label = video['title_atl']

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo('video', video['info'])
        list_item.setArt(video['arts'])

        is_folder = video['is_folder']

        if is_folder != True:
            list_item.setProperty('IsPlayable', 'true')

        url = video['url']

        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

def list_catalog( params ):
    xbmcplugin.setContent(_handle, 'movies')

    # Get the list of videos in the category.
    response = _tvzavr.get_catalog(params)

    if response['status'] != 0:
        show_error(response)
        return

    result = response.get('result')
    if result == None: total_count = 0
    else:
        total_count = result.get('total_count', 0)

    video_list = _tvzavr.get_video_list(response, params['action'])

    usearch = params.get('usearch', False)
    if not usearch and params['action']== 'search' and len(video_list) == 0:
        xbmcgui.Dialog().notification(local_str(30047), local_str(30056))
        return

    for video in video_list:
        if video['is_folder'] == True:
            url = get_url(action='episodes', clip_id=video['clip_id'])
        else:
            url = get_url(action='play', clip_id=video['clip_id'])
        video['url'] = url

    list_videos(video_list)

    limit = get_setting('limit')
    offset = int(params.get('_offset', 0))

    if total_count > offset + limit:
        list_item = xbmcgui.ListItem(label=local_str(30058))
        params['_offset'] = offset + limit
        url = '{0}?{1}'.format(_url, urlencode(params))
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)

def list_seasons(clip_id):
    xbmcplugin.setContent(_handle, 'tvshows')

    params = {'plf':'and', 'cid': clip_id}
    response = _tvzavr.get_seasons(clip_id)
    if response['status'] != 0:
        show_error(response)
        return

    video_list = _tvzavr.get_video_list(response, 'seasons')
    for video in video_list:
        video['url'] = get_url(action='episodes', clip_id=video['season_id'])

    list_videos(video_list);

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)

def list_series(season_id):
    xbmcplugin.setContent(_handle, 'episodes')

    limit = 50
    response = _tvzavr.get_series(season_id, limit)
    if response['status'] != 0:
        show_error(response)
        return

    total_count = response['result']['total_count']
    if total_count == 0:
        list_seasons(season_id)
        return
    elif total_count > limit:
        limit = total_count
        response = _tvzavr.get_series(season_id, limit)
        if response['status'] != 0:
            show_error(response)
            return

    video_list = _tvzavr.get_video_list(response, 'series')
    for video in video_list:
        video['url'] = get_url(action='play', clip_id=video['clip_id'])

    list_videos(video_list);

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)

    xbmcplugin.endOfDirectory(_handle)

def play_video(clip_id):

    response = _tvzavr.get_video_url(clip_id)
    if response['status'] != 0:
        show_error(response)
        return

    playlist_url = _tvzavr.get_playlist( response )
    if playlist_url == None:
        return
    #subtitles_url = response['video']['url'].replace('/stream/','/addons/', 1).replace('/[^/]*\\.m3u8','/rus.srt', 1)
    subtitles_url = response['video']['url'].replace('/stream/','/addons/', 1).replace('/mnf.m3u8','/rus.srt', 1)

    if debug: xbmc.log( '[%s]: sub - %s' % (_url, subtitles_url ), 3 )


    response = _tvzavr.get_video_info(clip_id)
    if response['status'] != 0:
        show_error(response)
        return

    video_data = _tvzavr.get_video_data(response['video_data'])

    play_item = xbmcgui.ListItem(path=playlist_url, label=video_data['title'])

    if get_setting('use_subtitles'):
        play_item.setSubtitles([subtitles_url])
    play_item.setInfo('video', video_data['info'])
    play_item.setArt(video_data['arts'])
    xbmcplugin.setResolvedUrl(_handle, True, play_item)


def list_search(params):

    history = params.get('history')
    if history == '1':
        list_item = xbmcgui.ListItem(label='Новый поиск')
        url = get_url(action='search')

        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = True

        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

        # Add a sort method for the virtual folder items (alphabetically, ignore articles)
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
        # Finish creating a virtual folder.
        xbmcplugin.endOfDirectory(_handle)
        return

    query = params.get('_query','')

    if query == '':
        kbd = xbmc.Keyboard()
        kbd.setDefault('')
        kbd.setHeading(local_str(30055))
        kbd.doModal()
        if kbd.isConfirmed():
            search_str = kbd.getText()#.decode('utf-8')
            if search_str != '':
                query = search_str

    if query != '':
        params['_query'] = query
        list_catalog(params)
    else:
        xbmcplugin.endOfDirectory(_handle, False)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if debug: xbmc.log( '[%s]: params - %s' % (_url,str(params)), 3 )
        action = params.get('action')
        mode = params.get('mode')
        if action:
            if action == 'catalog':
                list_catalog(params)
            elif action == 'favorites':
                list_catalog(params)
            elif action == 'paid':
                list_catalog(params)
            elif action == 'seasons':
                list_seasons(params['clip_id'])
            elif action == 'episodes':
                list_series(params['clip_id'])
            elif action == 'play':
                play_video(params['clip_id'])
            elif action == 'search':
                list_search(params)
            elif action == 'logout':
                logout()
            elif action == 'login':
                login()
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_categories()

def login():
    result = _tvzavr.login()

    if result['status'] != 0:
        show_error(result)
    else:
        cookie_values = result['cookie_values']
        _addon.setSetting('userid', cookie_values.get('userid',''))
        _addon.setSetting('vlog-ssid', cookie_values.get('vlog-ssid',''))
        _addon.setSetting('password', '')
        xbmcgui.Dialog().notification(local_str(30051), local_str(30052))
        _addon.openSettings()

def logout():
    result = _tvzavr.logout()

    if result['status'] != 0 and result['status'] != 9:
        show_error(result)
    else:
        cookie_values = result['cookie_values']
        _addon.setSetting('userid', cookie_values.get('userid',''))
        _addon.setSetting('vlog-ssid', cookie_values.get('vlog-ssid',''))
        xbmcgui.Dialog().notification(local_str(30053), local_str(30054))
        _addon.openSettings()

if __name__ == '__main__':
    debug = get_setting('debug')
    if debug: xbmc.log( '[%s]: %d %s' % (_url, _handle, sys.argv[2]), 3 )

    _tvzavr = init_tvzavr()

    router(sys.argv[2][1:])