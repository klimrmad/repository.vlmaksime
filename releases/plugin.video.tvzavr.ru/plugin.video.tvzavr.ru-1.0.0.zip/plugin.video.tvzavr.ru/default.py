# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import python_2_unicode_compatible

import os

import simplemedia
import xbmc
import xbmcgui
import xbmcplugin

from resources.libs.tvzavr import TVZavr, TVZavrException

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()


@python_2_unicode_compatible
class VideoInfo(simplemedia.VideoInfo):

    def __init__(self, data, for_play=False, atl_names=False):
        self._data = data

        self._path = None
        self._trailer = None

        self._for_play = for_play
        self._atl_names = atl_names and not for_play

    @property
    def genre(self):
        genres = self._data.get('genres')
        if genres is not None:
            return [genre['mark__name'] for genre in genres]

    @property
    def country(self):
        countries = self._data.get('countries')
        if countries is not None:
            return [country['mark__name'] for country in countries]

    @property
    def year(self):
        years = self._data.get('years')
        if years is not None:
            return int(years[0]['mark__name'])

    @property
    def episode(self):
        if self.mediatype == 'episode':
            return self._data['clip__position']

    @property
    def season(self):
        if self.mediatype == 'season':
            return self._data['clip__position']
        elif self.mediatype == 'episode':
            return self._data['clip__season_number'] or 1

    @property
    def cast(self):
        actors = self._data.get('actors')
        if actors is not None:
            return [actor['mark__name'] for actor in actors]

    @property
    def director(self):
        directors = self._data.get('directors')
        if directors is not None:
            return [director['mark__name'] for director in directors]

    @property
    def mpaa(self):
        age_limit = self._data.get('age_limit')
        if age_limit is not None \
          and age_limit:
            return '{0}+'.format(age_limit)

    @property
    def plot(self):
        return plugin.remove_html(self._data['clip__description'])

    @property
    def title(self):

        if self._atl_names:
            title = self.__atl_title()
        else:
            title = self.__title()

        if not self._for_play:
            title = title + self.__title_postfix()

        return title

    @property
    def original_title(self):
        if self.mediatype in ['movie', 'tvshow']:
            if self._data['clip__special_name']:
                return self._data['clip__special_name']

        return self.__title()

    @property
    def duration(self):
        if self.mediatype in ['movie', 'episode']:
            return self._data['clip__duration'] * 60

    @property
    def tvshowtitle(self):
        if self.mediatype in ['season', 'episode']:
            return self._data['clip__set_name']
        elif self.mediatype == 'tvshow':
            return self._data['clip__name']

    @property
    def tag(self):
        tags = self._data.get('tags')
        if tags is not None:
            return [tag['mark__name'] for tag in tags]

    @property
    def imdbnumber(self):
        return self._data['clip__imdb_id']

    @property
    def dateadded(self):
        return self._data.get('clip__date', '')

    @property
    def path(self):
        return self._path

    @property
    def trailer(self):
        if self.mediatype in ['movie', 'tvshow']:
            return self._trailer

    @property
    def mediatype(self):
        mediatype_ = getattr(self, '_mediatype', None)
        if mediatype_ is None:
            type_id = self._data['clip__type_id']
            if type_id == 1:
                mediatype_ = 'movie'
            elif type_id == 2:
                mediatype_ = 'tvshow'
            elif type_id == 3:
                mediatype_ = 'episode'
            elif type_id == 5:
                mediatype_ = 'season'
            self._mediatype = mediatype_

        return self._mediatype

    def __title(self):

        if self.mediatype == 'season':
            title = self._data['season__name']
        elif self.mediatype == 'episode' \
           and self._data['clip__name'] == '':
            title = '{0} {1}'.format(_('Episode'), self.episode)
        else:
            title = self._data['clip__name']

        return title

    def __title_postfix(self):
        if self._data['requires_subscription'] == 'Yes':
            tariffs_items = []

            tariffs_list = self._data.get('tariffs') or []
            for tariff in tariffs_list:
                if tariff['type_alias'] not in tariffs_items:
                    tariffs_items.append(tariff['type_alias'])

            postfix_parts = []
            if 'purchase' in tariffs_items:
                postfix_parts.append(_('Purchase'))
            if 'subscription' in tariffs_items:
                postfix_parts.append(_('Subscription'))

            if postfix_parts:
                return ' [{0}]'.format('/'.join(postfix_parts))

        return ''

    def __atl_title(self):

        title_parts = []
        if self.mediatype == 'movie':
             title_parts.append(self.original_title)
             if self.year is not None:
                 title_parts.append('({0})'.format(self.year))

        elif self.mediatype == 'episode':
             title_parts.append(self.tvshowtitle)
             title_parts.append('s%02de%02d' % (self.season, self.episode))
             if self._data['clip__name'] != '':
                 title_parts.append(self._data['clip__name'])

        else:
            title_parts.append(self.__title())

        return ' '.join(title_parts)

    def has_trailer(self):
        return self._data['clip__trailer_url'] != ''

    def set_trailer(self, trailer):
        self._trailer = trailer

    def set_path(self, path):
        self._path = path


@python_2_unicode_compatible
class VideoListItem(simplemedia.ListItemInfo):

    _img_url = 'http://cdn.tvzavr.ru/common/tvzstatic/cache'

    def __init__(self, video_info, default_rating='kinopoisk'):
        self._data = video_info._data
        self._video_info = video_info

        self._mediatype = video_info.mediatype
        self._default_rating = default_rating

        self._url = None
        self._path = None

        self.clip_id = self.__clip_id()
        self.season_id = self.__season_id()

        if video_info.has_trailer():
            trailer_path = plugin.url_for('play_trailer', clip_id=self.clip_id)
            video_info.set_trailer(trailer_path)

    @property
    def label(self):
        return self._video_info.title

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        return self._mediatype in ['movie', 'episode']

    @property
    def online_db_ids(self):
        db_ids = {'tvzavr': str(self.clip_id)}

        if self._data['clip__kp_id']:
            db_ids['kinopoisk'] = str(self._data['clip__kp_id'])
        if self._data['clip__imdb_id']:
            db_ids['imdb'] = self._data['clip__imdb_id']

        return db_ids

    @property
    def ratings(self):
        tvz_votes = self._data['clip__rates']
        tvz_ratesum = float(self._data['clip__ratesum']) * 2
        tvz_rating = 0 if tvz_votes == 0 else tvz_ratesum / tvz_votes

        ratings = [self._make_rating('kinopoisk', self._data['clip__kp_rate']),
                   self._make_rating('imdb', self._data['clip__imdb_rate']),
                   self._make_rating('tvzavr', tvz_rating, tvz_votes),
                   ]

        for rating in ratings:
            rating['defaultt'] = (rating['type'] == self._default_rating)

        return ratings

    @staticmethod
    def _make_rating(type_, rating, votes=0):
        if rating:
            rating = round(rating, 2)
        else:
            rating = 0

        return {'type': type_,
                'rating': rating,
                'votes': votes,
                'defaultt': False,
                }

    @property
    def art(self):
        return {'poster': self.poster()}

    def poster(self):
        return self._img_url + '/500x750/{0}.jpg'.format(self.clip_id)

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self.poster()
        elif self._mediatype == 'episode':
            return self._img_url + '/644x363/{0}.jpg'.format(self.clip_id)

    @property
    def fanart(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self._img_url + '/644x363/{0}.jpg'.format(self.clip_id)
        elif self._mediatype == 'episode':
            return self._img_url + '/644x363/{0}.jpg'.format(self._data['clip__parent_node_id'])

    @property
    def info(self):
        return {'video': self._video_info.get_info()}

    @property
    def url(self):
        return self._url

    def __clip_id(self):
        if self._mediatype in ['movie', 'tvshow', 'episode']:
            return self._data['clip__id']
        elif  self._mediatype in ['season']:
            if self._data['season__id'] is not None:
                return self._data['clip__parent_node_id']
            else:
                return self._data['clip__id']

    def __season_id(self):
        if self._mediatype in ['season']:
            return self._data['season__id']

    def set_url(self, url):
        self._url = url

    def set_path(self, path):
        self._path = path
        self._video_info.set_path(path)


@python_2_unicode_compatible
class EmptyListItem(simplemedia.ListItemInfo):

    @property
    def path(self):
        return self._path

    def set_path(self, path):
        self._path = path


@plugin.route('/login')
def login():
    _login = plugin.get_keyboard_text('', _('E-mail'))
    if not _login:
        return

    xbmc.sleep(1000)

    _password = plugin.get_keyboard_text('', _('Enter your password'), True)
    if not _password:
        return

    dialog = xbmcgui.Dialog()

    try:
        login_result = api.user_login(_login, _password)
    except TVZavrException as e:
        plugin.log_error(e.msg)
        dialog.ok(plugin.name, e.msg)
        return

    user_fields = _get_user_fields(login_result['user_info'])
    plugin.set_settings(user_fields)

    plugin.set_setting('dev_id', login_result['dev_id'])

    if user_fields['customer_nickname']:
        dialog.ok(plugin.name, _('You have successfully logged in'))
    else:
        dialog.ok(plugin.name, _('Incorrect login or password!'))


@plugin.route('/logout')
def logout():

    dialog = xbmcgui.Dialog()

    try:
        api.user_logout()

        default_uuid = plugin.get_setting('default_uuid')
        login_result = api.user_login(user_id=default_uuid)
        user_info = api.user_get_info()
    except TVZavrException as e:
        plugin.log_error(e.msg)
        dialog.ok(plugin.name, e.msg)
        return

    user_fields = _get_user_fields(user_info)
    plugin.set_settings(user_fields)
    plugin.set_setting('dev_id', login_result['dev_id'])

    dialog = xbmcgui.Dialog()
    dialog.ok(plugin.name, _('You have successfully logged out'))


@plugin.route('/')
def root():
    if plugin.params.action is not None:
        if plugin.params.action == 'search':
            search()
    else:
        plugin.create_directory(_root_items(), content='', category=plugin.name)


def _root_items():

    # Catalog
    for catalog_item in _catalog_items():

        url = plugin.url_for('catalog', cats=catalog_item['category'])
        listitem = {'label': catalog_item['title'],
                    'url': url,
                    'icon': catalog_item['icon'],
                    'fanart': plugin.fanart,
                    'content_lookup': False,
                    }
        yield listitem

    if plugin.get_setting('customer_regkey') != 'fakeuser':
        for catalog_item in _catalog_history_items():

            url = plugin.url_for('catalog_history', cat_type=catalog_item['category'])
            listitem = {'label': catalog_item['title'],
                        'url': url,
                        'icon': catalog_item['icon'],
                        'fanart': plugin.fanart,
                        'content_lookup': False,
                        }
            yield listitem

    # Search
    url = plugin.url_for('search_history')
    list_item = {'label': _('Search'),
                 'url': url,
                 'icon': plugin.get_image('DefaultAddonsSearch.png'),
                 'fanart': plugin.fanart,
                 'content_lookup': False,
                 }
    yield list_item


@plugin.route('/catalog/<cats>/')
def catalog(cats):

    offset = plugin.params.offset or '0'
    offset = int(offset)

    limit = plugin.params.limit or plugin.get_setting('limit', False)
    limit = int(limit)

    client_ctx = plugin.params.client_ctx
    sort = plugin.params.sort

    try:
        catalog_result = api.catalog(cats, client_ctx, offset, limit, sort)
    except TVZavrException as e:
        plugin.notify_error(e.msg)
        plugin.create_directory([], succeeded=False)
        return

    page_params = {'cats': cats,
                   }

    if sort is not None:
        page_params['sort'] = sort

    if client_ctx is not None:
        page_params['client_ctx'] = client_ctx

    _list_catalog(cats, 'catalog', offset, limit, catalog_result, page_params)


@plugin.route('/history/<cat_type>/')
def catalog_history(cat_type):

    offset = plugin.params.offset or '0'
    offset = int(offset)

    limit = plugin.params.limit or plugin.get_setting('limit', False)
    limit = int(limit)

    sort = plugin.params.sort

    try:
        catalog_result = api.catalog_history(cat_type, offset, limit, sort)
    except TVZavrException as e:
        plugin.notify_error(e.msg)
        plugin.create_directory([], succeeded=False)
        return

    page_params = {'cat_type': cat_type,
                   }

    if sort is not None:
        page_params['sort'] = sort

    _list_catalog(cat_type, 'catalog_history', offset, limit, catalog_result, page_params)


@plugin.route('/search/history')
def search_history():

    result = {'items': plugin.search_history_items(),
              'content': '',
              'category': ' / '.join([plugin.name, _('Search')]),
              }

    plugin.create_directory(**result)


@plugin.route('/search')
def search():

    keyword = plugin.params.keyword or ''
    usearch = plugin.params.usearch or ''
    is_usearch = (usearch.lower() == 'true')

    if not keyword:
        keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
          and not is_usearch:
            plugin.update_search_history(keyword)

            url = plugin.url_for('search', keyword=keyword)
            xbmc.executebuiltin('Container.Update("%s")' % url)

    elif keyword is not None:
        try:
            search_result = api.search_split(keyword)
        except TVZavrException as e:
            plugin.notify_error(e.msg)
            plugin.create_directory([], succeeded=False)
            return

        search_items = []
        for group_list in search_result['search_group_list']:
            search_items.extend(group_list['video_list'])

        result = {'items': _list_items(search_items),
                  'total_items': len(search_items),
                  'content': 'movies',
                  'category': ' / '.join([_('Search'), keyword]),
                  'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
                  }
        plugin.create_directory(**result)


def _list_catalog(category, action, offset, limit, catalog_result, page_params):

    pages = _get_pages(page_params, offset, limit, catalog_result['total_count'], action)

    catalog_info = _catalog_info(category)

    category_parts = [catalog_info['title'],
                      '{0} {1}'.format(_('Page'), int(offset / limit) + 1),
                      ]

    catalog_items = catalog_result['video_list']

    result = {'items': _list_items(catalog_items, pages),
              'total_items': len(catalog_items),
              'content': catalog_info['content'],
              'category': ' / '.join(category_parts),
              'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
              'update_listing': (offset > 0),
              }
    plugin.create_directory(**result)


@plugin.route('/series/<clip_id>/seasons/')
def seasons(clip_id):

    try:
        tvshow_result = api.video_get_info(clip_id)
        tvshow_info = VideoInfo(tvshow_result)

        seasons_result = api.video_get_seasons(clip_id)
    except TVZavrException as e:
        plugin.notify_error(e.msg)
        plugin.create_directory([], succeeded=False)
        return

    _category = tvshow_info.title

    seasons_items = seasons_result['seasons']
    total_items = len(seasons_items)
    if seasons_result['total_count'] > total_items:
        seasons_result = api.video_get_seasons(clip_id, total_items, seasons_result['total_count'])

        seasons_items.extend(seasons_result['seasons'])
        total_items = len(seasons_items)

    del seasons_result

    category_parts = [_category]

    if not seasons_items:
        fake_season = tvshow_result
        fake_season['season__name'] = '{0} 1'.format(_('Season'))
        fake_season['season__id'] = None
        fake_season['clip__position'] = 1
        fake_season['clip__type_id'] = 5

        seasons_items.append(fake_season)

    result = {'items': _list_items(seasons_items),
              'total_items': total_items,
              'content': 'seasons',
              'category': ' / '.join(category_parts),
              'sort_methods': xbmcplugin.SORT_METHOD_LABEL,
              }
    plugin.create_directory(**result)


@plugin.route('/series/<clip_id>/episodes/', 'episodes_without_season')
@plugin.route('/series/<clip_id>/seasons/<season_id>/episodes/')
def episodes(clip_id, season_id=None):

    use_atl_names = _use_atl_names()

    try:
        tvshow_result = api.video_get_info(clip_id)
        tvshow_info = VideoInfo(tvshow_result)

        del tvshow_result

        if season_id is None:
            episodes_result = api.video_get_childs(clip_id)
        else:
            episodes_result = api.video_get_series(season_id)
    except TVZavrException as e:
        plugin.notify_error(e.msg)
        plugin.create_directory([], succeeded=False)
        return

    _category = tvshow_info.title

    episodes_items = episodes_result['series']
    total_items = len(episodes_items)
    if episodes_result['total_count'] > total_items:
        if season_id is None:
            episodes_result = api.video_get_childs(clip_id, total_items, episodes_result['total_count'])
        else:
            episodes_result = api.video_get_series(season_id, total_items, episodes_result['total_count'])

        episodes_items.extend(episodes_result['series'])
        total_items = len(episodes_items)

    del episodes_result

    category_parts = [_category]

    if use_atl_names:
        sort_methods = xbmcplugin.SORT_METHOD_NONE
    else:
        sort_methods = xbmcplugin.SORT_METHOD_EPISODE

    result = {'items': _list_items(episodes_items),
              'total_items': total_items,
              'content': 'episodes',
              'category': ' / '.join(category_parts),
              'sort_methods': sort_methods,
              }
    plugin.create_directory(**result)


@plugin.route('/video/<clip_id>/play')
def play_video(clip_id):
    succeeded = True

    is_strm = plugin.params.strm == '1' \
               and plugin.kodi_major_version() >= '18'

    try:
        if is_strm:
            list_item = EmptyListItem()
        else:

            default_rating = _get_rating_source()

            video_result = api.video_get_info(clip_id)
            video_info = VideoInfo(video_result, True)
            list_item = VideoListItem(video_info, default_rating)

        url_info = api.video_url(clip_id)

        list_item.set_path(_get_playlist_url(url_info))

    except TVZavrException as e:
        plugin.log_error(e.msg)
        dialog = xbmcgui.Dialog()
        dialog.ok(plugin.name, e.msg)
        succeeded = False

    plugin.resolve_url(list_item.get_item(), succeeded)


@plugin.route('/video/<clip_id>/trailer')
def play_trailer(clip_id):
    succeeded = True

    listitem = {}

    try:
        url_info = api.video_trailer_url(clip_id)

        listitem['path'] = _get_playlist_url(url_info)

    except TVZavrException as e:
        plugin.log_error(e.msg)
        dialog = xbmcgui.Dialog()
        dialog.ok(plugin.name, e.msg)
        succeeded = False

    plugin.resolve_url(listitem, succeeded)


def _list_items(items, pages=None):

    use_atl_names = _use_atl_names()

    ext_dir_params = {}
    ext_item_params = {}
    if use_atl_names:
        ext_dir_params['atl'] = 1
        ext_item_params['strm'] = 1

    default_rating = _get_rating_source()

    for item in items:

        video_info = VideoInfo(item, atl_names=use_atl_names)
        list_item = VideoListItem(video_info, default_rating)

        if video_info.mediatype in ['movie', 'episode']:
            url = plugin.url_for('play_video', clip_id=list_item.clip_id, **ext_item_params)
        elif video_info.mediatype == 'tvshow':
            url = plugin.url_for('seasons', clip_id=list_item.clip_id, **ext_dir_params)
        elif video_info.mediatype == 'season':
            if list_item.season_id is not None:
                url = plugin.url_for('episodes', clip_id=list_item.clip_id, season_id=list_item.season_id, **ext_dir_params)
            else:
                url = plugin.url_for('episodes_without_season', clip_id=list_item.clip_id, **ext_dir_params)

        list_item.set_url(url)

        yield list_item.get_item()

    if pages is not None:
        if pages['prev'] is not None:
            url = plugin.url_for(pages['action'], **pages['prev'])
            listitem = {'label': _('Previous page...'),
                        'fanart': plugin.fanart,
                        'is_folder': True,
                        'url':   url}
            yield listitem

        if pages['next'] is not None:
            url = plugin.url_for(pages['action'], **pages['next'])
            listitem = {'label': _('Next page...'),
                        'fanart': plugin.fanart,
                        'url':   url,
                        'content_lookup': False,
                        }
            yield listitem


@plugin.cached(30)
def _catalog_navigation_menu():
    return api.catalog_navigation_menu()


def _catalog_items():
    try:
        catalog_items = _catalog_navigation_menu()
    except TVZavrException as e:
        catalog_items = []
        plugin.notify_error(e.msg)

    movie_icon = plugin.get_image('DefaultMovies.png')
    tvshow_icon = plugin.get_image('DefaultTVShows.png')

    for item in catalog_items:
        is_tvshow = (item['category'] == '675')

        yield {'category': item['category'],
               'title': item['title'],
               'icon': tvshow_icon if is_tvshow else movie_icon,
               'content':'tvshows' if is_tvshow else 'movies',
               }


def _catalog_history_items():

    favirote_icon = plugin.get_image('DefaultFavourites.png')

    yield {'category': 'favorites',
           'title': _('Favorites'),
           'icon': favirote_icon,
           'content': 'movies',
           }

    yield {'category': 'purchased',
           'title': _('Purchases'),
           'icon': favirote_icon,
           'content': 'movies',
           }


def _catalog_info(category):

    for catalog_item in _catalog_items():
        if category == catalog_item['category']:
            return catalog_item

    for catalog_item in _catalog_history_items():
        if category == catalog_item['category']:
            return catalog_item


def _get_playlist_url(url_info):
    import m3u8

    user_id = plugin.get_setting('customer_uuid') or 'NULL'
    playlist_url = api.get_playlist_url(url_info['url'], url_info['uuid'], user_id)

    qualities = [240, 360, 480, 720, 1080, 2160]
    video_quality = plugin.get_setting('video_quality')
    quality = qualities[video_quality]

    variant_m3u8 = m3u8.load(playlist_url)

    video_url = None

    for playlist in variant_m3u8.playlists:

        resolution = playlist.stream_info.resolution
        if resolution is not None \
          and (video_url is None or resolution[1] <= quality):
            video_url = playlist.base_uri + playlist.uri

    return video_url


def _get_cookie_path():
    return os.path.join(plugin.profile_dir, 'tvzavr.cookies')


def _api():
    cookie_file = _get_cookie_path()

    headers = {}
    if plugin.kodi_major_version() >= '17':
        headers['User-Agent'] = xbmc.getUserAgent()

    plf = 'htm'
    plf_secret = 'c58ad145141cedc57523c6305b6df7960ca844371d325db23412abc8e884c114'

    api = TVZavr(plf, plf_secret, headers, cookie_file)

    default_uuid = plugin.get_setting('default_uuid')
    if not default_uuid:
        user_info = api.register()
        user_fields = _get_user_fields(user_info)
        plugin.set_settings(user_fields)
        plugin.set_setting('default_uuid', user_fields['customer_uuid'])

        login_result = api.user_login(user_id=user_fields['customer_uuid'])
        plugin.set_setting('dev_id', login_result['dev_id'])

    return api


def _get_user_fields(user_info=None):
    user_info = user_info or {}

    customer_gender = user_info.get('customer__gender') or ''
    if customer_gender == 'male':
        customer_gender_id = 1
    elif customer_gender == 'female':
        customer_gender_id = 2
    else:
        customer_gender_id = 0

    fields = {'customer_name': user_info.get('customer__name') or '',
              'customer_nickname': user_info.get('customer__nickname') or '',
              'customer_gender': customer_gender_id,
              'customer_birthday': user_info.get('customer__birthday') or '',
              'customer_regkey': user_info.get('customer__regkey') or '',
              'customer_uuid': user_info.get('customer__uuid') or '',
              'customer_uid': user_info.get('customer__uid') or '',
              }

    return fields


def _get_pages(page_params, offset, limit, total, action):

    # Parameters for previous page
    if offset >= limit:
        prev_offset = offset - limit
        if prev_offset > 0:
            prev_page = {'offset': prev_offset,
                         'limit': limit,
                         }
            prev_page.update(page_params)
        else:
            prev_page = page_params
    else:
        prev_page = None

    # Parameters for next page
    next_offset = offset + limit
    if total > next_offset:
        next_page = {'offset': next_offset,
                     'limit': limit,
                     }
        next_page.update(page_params)
    else:
        next_page = None

    pages = {'action': action,
             'prev': prev_page,
             'next': next_page,
             }

    return pages


def _get_rating_source():
    rating_source = plugin.get_setting('video_rating')
    if rating_source == 0:
        source = 'kinopoisk'
    elif rating_source == 1:
        source = 'imdb'
    else:
        source = 'tvzavr'

    return source


def _use_atl_names():
    return plugin.params.get('atl', '') == '1' \
             or plugin.get_setting('use_atl_names')


if __name__ == '__main__':
    api = _api()
    plugin.run()
