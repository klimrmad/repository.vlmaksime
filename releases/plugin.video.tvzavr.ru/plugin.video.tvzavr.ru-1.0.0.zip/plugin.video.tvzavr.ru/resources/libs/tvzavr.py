# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import PY3, iteritems, python_2_unicode_compatible

if PY3:
    from urllib.parse import urlencode, quote_plus, urlparse
    import http.cookiejar as cookielib
else:
    from future.backports.urllib.parse import urlencode, quote_plus, urlparse
    import cookielib

import sys
import os
import requests

__all__ = ['TVZavr', 'TVZavrException']

@python_2_unicode_compatible
class http_client(object):

    def __init__(self, headers=None, cookie_file=None):
        self._s = requests.Session()

        if cookie_file is not None:
            self._s.cookies = cookielib.LWPCookieJar(cookie_file)
            if os.path.exists(cookie_file):
                self._s.cookies.load(ignore_discard=True, ignore_expires=True)

        self.update(headers)

    def update(self, headers=None):

        if headers is not None and headers:
            self._s.headers.update(headers)

    def _save_cookies(self):
        if isinstance(self._s.cookies, cookielib.LWPCookieJar) \
           and self._s.cookies.filename:
            self._s.cookies.save(ignore_expires=True, ignore_discard=True)

    def post(self, url, **kwargs):

        r = self._s.post(url, **kwargs)
        r.raise_for_status()

        self._save_cookies()

        return r

    def get(self, url, **kwargs):

        r = self._s.get(url, **kwargs)
        r.raise_for_status()

        self._save_cookies()

        return r


@python_2_unicode_compatible
class TVZavrException(Exception):

    def __init__(self, msg, code=None):
        self.msg = msg
        self.code = code

    def __str__(self):
        return self.msg

@python_2_unicode_compatible
class TVZavr(object):

    _api_url = 'http://api.tvzavr.ru/api'

    def __init__(self, plf, plf_secret, headers=None, cookies=None, **kwargs):

        params = kwargs or {}

        self._plf = plf
        self._plf_secret = plf_secret
        self._lang = params.get('lang', 'rus')

        headers = headers or {}

        f_headers = {'User-Agent': None,
                     'Accept-Encoding': 'gzip',
                     'Connection': 'keep-alive',
                     }
        f_headers.update(headers)

        self._client = http_client(f_headers, cookies)

    def _post(self, url, params=None, **kwargs):
        params = params or {}

        url = self._api_url + url

        try:
            r = self._client.post(url, params=params, **kwargs)
        except requests.ConnectionError:
            raise TVZavrException('Connection error')
        except requests.HTTPError as e:
            raise TVZavrException(str(e))

        return r

    def _get(self, url, params=None, **kwargs):
        params = params or {}

        url = self._api_url + url

        try:
            r = self._client.get(url, params=params, **kwargs)
        except requests.ConnectionError:
            raise TVZavrException('Connection error')
        except requests.HTTPError as e:
            raise TVZavrException(str(e))

        return r

    def _extract_json(self, r):
        try:
            j = r.json()
        except ValueError as err:
            raise TVZavrException(err)

        if isinstance(j, dict) \
          and j['status'] != 0:
            error = j['error']
            if isinstance(error, list):
                raise TVZavrException(error[0]['description_ru'], j['status'])
            else:
                raise TVZavrException(error['description_ru'], j['status'])

        return j

    def register(self):
        url = '/3.0/user/register'

        u_data = {'fake':1,
                  }

        u_params = {'plf': self._plf,
                    }

        r = self._post(url, params=u_params, data=u_data)
        j = self._extract_json(r)

        return j['user_info']

    def user_login(self, login=None, password=None, user_id=None):
        url = '/3.1/user/login'

        if login is None \
          and user_id is not None:
            u_params = {'plf': self._plf,
                        'user_id': user_id,
                        }
            r = self._get(url, params=u_params)
        else:
            u_params = {'plf': self._plf,
                        }
            u_data = {'email': login,
                      'password': password}
            r = self._post(url, params=u_params, data=u_data)
        j = self._extract_json(r)
        return j['result']

    def user_logout(self):
        url = '/3.0/user/logout'

        r = self._post(url)
        self._extract_json(r)

    def user_get_info(self):
        url = '/3.0/user/get_info'

        u_params = {'plf': self._plf,
                    }
        r = self._post(url, params=u_params)
        j = self._extract_json(r)

        return j['user_info']


    def catalog_navigation_menu(self):
        url = '/3.0/catalog/navigation_menu'

        u_params = {'lang': self._lang,
                    }

        r = self._get(url, params=u_params)
        j = self._extract_json(r)

        return j['result']['navigation_menu']

    def catalog(self, cats=None, client_ctx=None, offset=0, limit=20, sort=None):
        url = '/3.1/catalog/get'

        u_params = {'show_marks': 'true',
                    'recomended': 'no',
                    'plf': self._plf,
                    'sort': sort,
                    'cats': cats,
                    'offset': offset,
                    'limit': limit,
                    'client_ctx': client_ctx,
                    'lang': self._lang,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['result']

    def catalog_history(self, type_, offset=0, limit=20, sort=None):
        url = '/3.1/catalog/history'

        u_params = {'show_marks': 'true',
                    'plf': self._plf,
                    'sort': sort,
                    'type': type_,
                    'offset': offset,
                    'limit': limit,
                    'lang': self._lang,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['result']

    def search_split(self, query):
        url = '/3.0/search/split'

        u_params = {'plf': self._plf,
                    'sort': 'issue',
                    'redirect': 'false',
                    'query': query,
                    'lang': self._lang,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['search_split_list']


    def video_get_info(self, clip_id):
        url = '/3.0/video/get_info'

        u_params = {'cid': clip_id,
                    'plf': self._plf,
                    'void': 'true',
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['video_data']

    def video_get_seasons(self, clip_id, offset=0, limit=10, fake_seasons=False):
        url = '/3.0/video/get_seasons'

        u_params = {'cid': clip_id,
                    'offset': offset,
                    'limit': limit,
                    'fake_seasons': 'true' if fake_seasons else None,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['result']

    def video_get_series(self, season_id, offset=0, limit=10):
        url = '/3.0/video/get_series'

        u_params = {'cid': season_id,
                    'offset': offset,
                    'limit': limit,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['result']

    def video_get_childs(self, clip_id, offset=0, limit=10):
        url = '/3.0/video/get_childs'

        u_params = {'cid': clip_id,
                    'offset': offset,
                    'limit': limit,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['result']

    def video_url(self, clip_id):
        url = '/3.0/video/url'

        u_params = {'cid': clip_id,
                    'plf': self._plf,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['video']

    def video_trailer_url(self, clip_id):
        url = '/3.0/video/trailer_url'

        u_params = {'cid': clip_id,
                    'plf': self._plf,
                    }

        r = self._get(url, u_params)
        j = self._extract_json(r)

        return j['video']

    def get_playlist_url(self, url, stream_uuid, user_id):
        url_parts = urlparse(url)

        session_key = self._session(url_parts, stream_uuid, user_id)
        token = self._generate_token(session_key, url)

        path = url_parts.path.replace('/mnf.m3u8', '/v5-mnf.m3u8')

        u_params = {'usessionid': session_key,
                    'pageurl': 'null',
                    'token': token,
                    'platform': self._plf,
                    }
        url_parts = url_parts._replace(query=urlencode(u_params), path=path)

        return url_parts.geturl()

    def _session(self, url_parts, stream_uuid, user_id):

        u_params = {'platform': self._plf,
                    'url': stream_uuid,
                    'UserId': user_id,
                    }

        url_parts = url_parts._replace(path='/session', query=urlencode(u_params))
        url = url_parts.geturl()

        r = self._client.get(url)

        return r.text

    def _generate_token(self, session_key, stream_url):
        import hashlib
        random32 = self._random32()
        hash_string = '{0}{1}{2}null{3}'.format(session_key, stream_url, random32, self._plf_secret)
        return '{0}{1}'.format(random32, hashlib.sha256(hash_string.encode('utf-8')).hexdigest())

    @staticmethod
    def _random32():
        import math
        import random

        result = ''
        charsets = '0123456789abcdef'
        while(len(result) < 32):
            index = int(math.floor(random.random() * 15))
            result = result + charsets[index]
        return result
