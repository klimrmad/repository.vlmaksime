# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from .tvzavr import *
from .tvzavr_items import *
