# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals
from future.utils import iteritems, python_2_unicode_compatible

import requests
import hashlib

@python_2_unicode_compatible
class VideoMore(object):

    _api_url = 'http://videomore.ru/api'

    class ApiException(Exception):
        """Custom exception"""
        pass

    def __init__(self, app_id, secret, device_id='unknown'):

        self._app_id = app_id
        self._secret = secret
        self.device_id = device_id

    def __str__(self):
        return '<App_id: {0}; Secret: {1}***{2}; Device_id: {3}>'.format(self._app_id, self._secret[0:3], self._secret[-3:], self.device_id)

    def _get_url_signature(self, **kwargs):

        kwargs = kwargs or {}

        sig_url = ''
        for key in sorted(kwargs):
            if kwargs[key]:
                sig_url += '{0}={1}&'.format(key, kwargs[key])

        sig_url = '{0}{1}'.format(sig_url[0:-1], self._secret)

        md5 = hashlib.md5()
        md5.update(sig_url.encode('utf-8'))

        return md5.hexdigest()

    def _http_request(self, url, params=None):
        params = params or {}

        r_params = {'app_id': self._app_id,
                    'sig': self._get_url_signature(app_id=self._app_id, **params)}
        r_params.update(params)

        try:
            r = requests.get(url, r_params)
            r.raise_for_status()
        except requests.ConnectionError:
            raise self.ApiException('Connection error')
        except requests.exceptions.HTTPError:
            raise self.ApiException('Request error')

        return r

    def _extract_json(self, r):
        try:
            j = r.json()
        except ValueError as err:
            raise self.ApiException(err)

        if isinstance(j, dict) \
          and j.get('error') is not None:
            raise self.ApiException(j['error']['message'].encode('utf-8'))
        return j

    def projects(self, params):

        u_params = {'page': params.get('page', 1),
                    'per_page': params.get('per_page', 10),
                     }
        if params.get('channel') is not None:
            u_params['channel'] = params['channel']
        if params.get('category_id') is not None:
            u_params['category_id'] = params['category_id']
        if params.get('project_id') is not None:
            u_params['project_id'] = params['project_id']

        url = self._api_url + '/projects.json';
        r = self._http_request(url, u_params)
        projects = self._extract_json(r)

        result = {'count': len(projects),
                  'page': u_params['page'],
                  'per_page': u_params['per_page'],
                  'list': self._projects_list(projects),
                  }
        return result

    def _projects_list(self, projects):
        for project in projects:
            yield self._project_info(project)


    def partner_genres(self, category_id):
        u_params = {'category_id': category_id,
                    }

        url = self._api_url + '/partner_genres.json';
        r = self._http_request(url, u_params)

        genres = self._extract_json(r)

        for genre in genres:
            yield {'title': genre['title'],
                   'id': genre['id'],
                   }

    def allchannels(self):
        url = self._api_url + '/allchannels.json';
        r = self._http_request(url)

        channels = self._extract_json(r)

        for channel in channels:
            yield {'title': channel['title'],
                   'id': channel['id'],
                   'name': channel['name'],
                   'enabled': channel['enabled'],
                   'pos': channel['pos'],
                   'logo': channel['logo'],
                   }

    def projects_by_genres(self, category_id, genres_ids):

        u_params = {'category_id': category_id,
                    'genres_ids': genres_ids}
        url = self._api_url + '/projects_by_genres.json';
        r = self._http_request(url, u_params)
        projects = self._extract_json(r)

        params = {'project_id': (', '.join(str(project['id']) for project in projects)),
                  'per_page': len(projects),
                  }
        return self.projects(params)

    def project(self, project_id):

        params = {'project_id': project_id,
                  'page': 1,
                  'per_page': 1,
                  }

        url = self._api_url + '/projects.json';
        r = self._http_request(url, params)
        projects = self._extract_json(r)
        project = projects[0]

        return self._project_info(project)

    def search_projects(self, keyword):

        url = self._api_url + '/search_projects.json';
        u_params = {'q': keyword,
                    }
        r = self._http_request(url, u_params)
        projects = self._extract_json(r)

        params = {'project_id': (', '.join(str(project['id']) for project in projects)),
                  'per_page': len(projects),
                  }
        return self.projects(params)

    def project_seasons(self, project_id):

        u_params = {'project_id': project_id,
                    'page': 1,
                    'per_page': 1,
                    }

        url = self._api_url + '/projects.json';
        r = self._http_request(url, u_params)
        projects = self._extract_json(r)

        project = projects[0]
        result = {'count': len(project['project_seasons']),
                  'project': self._project_info(project),
                  'list': self._project_seasons_list(project),
                  }
        return result

    @staticmethod
    def _project_seasons_list(project):
        for season_id, season in iteritems(project['project_seasons']):
            item = {'id': season_id,
                    'pos': season['pos'],
                    'title': season['title'],
                    'type': season['type'],
                    'published': season['published'],
                    }

            yield item

    def project_episodes(self, project_id, season_id=''):
        max_per_page = 100
        project_info = self.project(project_id)

        u_params = {'project_id': project_id,
                    'page': 1,
                    'per_page': min(project_info['count_episodes'], max_per_page),
                    'published': 'true',
                    'order': 'episode asc',
                    'device_id': self.device_id,
                    }
        if season_id:
            u_params['season_id'] = season_id

        url = self._api_url + '/tracks.json';

        all_episodes = []
        while True:
            r = self._http_request(url, u_params)
            episodes = self._extract_json(r)
            all_episodes.extend(episodes)
            u_params['page'] += 1
            if len(all_episodes) >= project_info['overall_episodes'] \
              or len(episodes) < max_per_page:
                break

        result = {'count': len(all_episodes),
                  'project': project_info,
                  'list': self._project_episodes_list(all_episodes),
                  }
        return result

    def project_episode(self, track_id):

        params = {'track_id': track_id}

        url = self._api_url + '/track.json';
        r = self._http_request(url, params)
        episode = self._extract_json(r)

        return self._episode_info(episode)

    def _project_episodes_list(self, episodes):
        for episode in episodes:
            yield self._episode_info(episode)

    @staticmethod
    def _project_info(project):
        item = {'description': project['description'],
                'id': project['id'],
                'min_age': project['min_age'],
                'rating': project['rating'],
                'title': project['title'],
                'country': project['country'].split(', '),
                'genre': project['genre'].split(', '),
                'director': project['director'].split(', '),
                'count_episodes': project['cnt_episode'],
                'overall_episodes': project['overall_count'],
                'paid': project['paid'],
                'updated': project['updated'],
                'count_season': project['count_season'],
                'poster': project['vertical_logo'],
                'thumbnail': project['big_thumbnail'],
                'fanart': project['normal_picture'],
                'banner': project['slide_original'],
                'category_id': project['category_id'],
                'year': int(project['year'][0:4]) if project['year'] else None,
                }

        return item

    @classmethod
    def _episode_info(cls, episode):
        if episode.get('geolocation') is not None:
            geolocation_allow = episode['geolocation']['allow']
        else:
            geolocation_allow = True

        item = {'description': episode['description'],
                'id': episode['id'],
                'duration': episode['duration'],
                'title': episode['title'],
                'project_id': episode['project_id'],
                'parent_id': episode['parent_id'],
                'rating': episode['rating'],
                'project_title': episode['project_title'],
                'updated': episode['updated'],
                'published': episode['published'],
                'published_at': episode['published_at'],
                'encrypted': episode['encrypted'],
                'external': episode['external'],
                'season_id': episode['season_id'],
                'season_pos': episode['season_pos'],
                'season_title': episode['season_title'],
                'hd': episode['hd'],
                'season_type': episode['season_type'],
                'min_age': episode['min_age'],
                'episode_of_season': episode['episode_of_season'],
                'thumbnail': episode['big_thumbnail_url'],
                'geolocation_allow': geolocation_allow,
                'paid': episode['paid'],
                'url_shared': episode['url_shared'],
                }

        if item['geolocation_allow']:
            item.update({'q1': episode['q1'],
                         'q2': episode['q2'],
                         'q3': episode['q3'],
                         'q4': episode['q4'],
                         'q5': episode['q5'],
                         'hls': episode['hls'],
                         })

            if episode['encrypted']:
                item.update({'widevine': episode['widevine'],
                             'widevine_xml': episode['widevine_xml'],
                             'widevine_modular': cls._get_direct_link(episode['widevine_modular']),
                             })
        return item

    @staticmethod
    def _get_direct_link(url):
        if not url[0:3] == 'http':
            return url

        r = requests.head(url)
        if r.status_code == 302:
            return r.headers['location']
        else:
            return url

    @staticmethod
    def get_age_restricted_rating(min_age, rating_type):
        rars = min_age
        if min_age == '0+':
            mpaa = 'G'
        elif min_age == '6+':
            mpaa = 'PG'
        elif min_age == '12+':
            mpaa = 'PG-13'
        elif min_age == '16+':
            mpaa = 'R'
        elif min_age == '18+':
            mpaa = 'NC-17'
        else:
            mpaa = ''

        result = {'rars': rars,
                  'mpaa': mpaa,
                  }

        return result.get(rating_type, '')